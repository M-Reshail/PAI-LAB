from flask import Flask, render_template
import requests

app = Flask(__name__)

API_KEY = "a4dc2c0163784a77a7e7ae5f689a7ce2" 

@app.route("/")
def home():
    country = "us"  
    url = f"https://newsapi.org/v2/top-headlines?country={country}&apiKey={API_KEY}"
    
    response = requests.get(url)
    articles = []

    if response.status_code == 200:
        data = response.json()
        articles = data.get('articles', [])
    else:
        print(f"Error fetching news: {response.status_code}")
        return render_template("index.html", error="Error fetching news. Please try again later.")

    return render_template("index.html", articles=articles)

if __name__ == "__main__":
    app.run(debug=True)
